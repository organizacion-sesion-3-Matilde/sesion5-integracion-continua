# En principio el alumno solo recibiría la definición de la función en el archivo correspondiente
def suma(x,y):

    # El alumno deberá implementar correctamente el código de la función para pasar el test correspondiente
    return x + y

def espar(x):
    if a % 2 == 0:
    return True
else:
    return False

